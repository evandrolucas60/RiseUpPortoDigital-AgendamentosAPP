const colaboradores = [
    {
        matricula:"01277902",
        senha:"clara_marinho",
        informacoes:{
            nome: "Clara Marinho",
            email: "marinho.claramb@gmail.com"
        },
        profile_pic: "https://cdn.britannica.com/77/234477-050-DF90E2ED/Doberman-pinscher-dog.jpg"
    },
    {
        matricula:"01277804",
        senha:"lohhan_gui",
        informacoes:{   
            nome: "Lohhan Guilherme",
            email: "email@gmail.com"
        },
        profile_pic: "https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTA4L3Jhd3BpeGVsX29mZmljZV8xMl9waG90b19vZl9nb2xkZW5fcmV0cmlldmVyX3B1cHB5X2p1bXBpbmdfaXNvbF83MTM2NGE2OS1kZTM0LTQzMWEtYWRkZS04ZTdmZWQ0ZGFiOTIucG5n.png"
    },
    ,
    {
        matricula:"123456",
        senha:"alexandre",
        informacoes:{   
            nome: "Alexandre Santana",
            email: "email@gmail.com"
        },
        profile_pic: "https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTA4L3Jhd3BpeGVsX29mZmljZV8xMl9waG90b19vZl9nb2xkZW5fcmV0cmlldmVyX3B1cHB5X2p1bXBpbmdfaXNvbF83MTM2NGE2OS1kZTM0LTQzMWEtYWRkZS04ZTdmZWQ0ZGFiOTIucG5n.png"
    },
]

export default colaboradores;
