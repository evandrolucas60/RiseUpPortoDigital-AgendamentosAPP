const fornecedores = [
    {
        id_fornecedor:"masterboi_0378",
        senha:"12345",
        informacoesLegais:["MASTERBOI LTDA.", "MASTERBOI", "03.721.769/0002-78"],
    },
    {
        id_fornecedor:"perdigao_8640",
        senha:"544321",
        informacoesLegais:["Perdigao Agroindustrial S/A", "Perdigao", "86.547.619/0250-40"],
    },
    {
        id_fornecedor:"vitarella_0765",
        senha:"1357910",
        informacoesLegais:["M Dias Branco S.A. Industria E Comercio De Alimentos", "Filial Vitarella", "07.206.816/0052-65"],
    }
]

export default fornecedores;